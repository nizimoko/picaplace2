# picaplace

> npm i (for both server and client)

> npm run server (in server)
> npm start (for the client)
